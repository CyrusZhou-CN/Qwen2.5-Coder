# Visualization Task - Simple

## Category
Composition

## Instruction
Create a pie chart showing the composition of fish species in Sweden by their Red List Status. Display the percentage distribution of different conservation statuses (e.g., "Not evaluated", "Least Concern", "Vulnerable", etc.) with appropriate colors and labels. Include the actual count for each status category in the labels and ensure the chart has a clear title.

## Files
List of fishes found in Sweden.csv

-------

