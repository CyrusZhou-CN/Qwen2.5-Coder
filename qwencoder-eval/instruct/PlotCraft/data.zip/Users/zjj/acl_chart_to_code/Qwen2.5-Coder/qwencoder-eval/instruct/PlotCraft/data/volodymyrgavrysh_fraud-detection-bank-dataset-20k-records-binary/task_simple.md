# Visualization Task - Simple

## Category
Distribution

## Instruction
Create a histogram to visualize the distribution of transaction amounts (col_67) in the fraud detection dataset. Use 20 bins and add appropriate labels, title, and styling to clearly show how transaction amounts are distributed across the dataset.

## Files
fraud_detection_bank_dataset.csv

-------

