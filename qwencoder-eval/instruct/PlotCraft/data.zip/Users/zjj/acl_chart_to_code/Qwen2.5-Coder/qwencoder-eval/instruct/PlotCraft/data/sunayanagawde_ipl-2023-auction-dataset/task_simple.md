# Visualization Task - Simple

## Category
Composition

## Instruction
Create a pie chart showing the distribution of player types (Batter, Bowler, All-Rounder, etc.) in the IPL 2023 auction dataset. Display the percentage for each player type and use distinct colors for each segment. Include a title and ensure the chart clearly shows which player type category dominates the auction purchases.

## Files
IPL_2023-22_Sold_Players.csv

-------

