# Visualization Task - Simple

## Category
Composition

## Instruction
Create a pie chart showing the distribution of brewery types in the dataset. Display the percentage for each brewery type and use distinct colors for each slice. Add a title "Distribution of Brewery Types in California" and ensure the chart is well-formatted with a legend.

## Files
breweries_us.csv

-------

