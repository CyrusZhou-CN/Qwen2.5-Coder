# Visualization Task - Simple

## Category
Distribution

## Instruction
Create a histogram showing the distribution of Netflix content release years. Use appropriate binning to reveal patterns in Netflix's content acquisition or production timeline, and include proper labels, title, and styling to make the visualization informative and visually appealing.

## Files
Netflix Data new.csv

-------

